# Aula 1
print("Meu texto")

def saudacao():
    print("Minha saudação")

if __name__ == "__main__":
    saudacao()

# Aula 2 - Indentação
if 10 > 15:
    # Imprime o resultado da comparação
    print("10 realmente é maior 5")
    # Imprime que a operação finalizou
    print("Operação finalizada")
    # Imprime a conslusão do if
    print("Terminando o if")

# Aula 3 - Blocos em Python
if 70 > 18:
    print("Você é maior de idade")
    # Verifica se o usuário é idoso e mostra uma mensagem
    if 70 > 65:
        print("Você é considerado idoso")

# Aula 4 - Comentários


# Aula 5 - Função print
print("Exibir uma mensagem")

print("Exibir", "Mensagem")

print("Laranja", "Maçã", "Banana", sep=" - ")

print("Carregando", end="...")