# Aula 6 - Recebendo dados com input
# nome_usuario = input("Digite o seu nome: ")

# print("O seu nome é", nome_usuario)

# aula 7 - Variáveis
temperatura = 32

temperatura = temperatura + 12

print(temperatura)

classe = "Mago"

character_class = "Guerreiro"

# class, if, else, def, for, while...

# aula 8 - Tipagem dinamica
numero = 10

# int -> integer -> inteiro -> numero inteiro
print(type(numero))

numero = "dez"

numero_em_texto = "dez"

# str -> string -> texto
print(type(numero))

# erro -> print(numero + 5)

