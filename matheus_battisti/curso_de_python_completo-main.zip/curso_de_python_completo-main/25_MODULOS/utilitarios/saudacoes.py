def saudacao():
    print("Olá Mundo!")