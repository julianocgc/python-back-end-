def somar(a, b):
    return a + b

"""
    O que faz o módulo calculadora?
    O que faz a função subtrair?
"""
def subtrair(a, b):
    return a - b