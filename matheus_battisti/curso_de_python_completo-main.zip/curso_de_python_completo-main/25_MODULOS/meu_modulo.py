def saudacao(nome):
    return f"Olá, {nome}!"