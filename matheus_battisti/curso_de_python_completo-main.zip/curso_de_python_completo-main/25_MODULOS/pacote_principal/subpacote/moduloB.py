

def funcaoB():
    print("Função do Sub Pacote")


