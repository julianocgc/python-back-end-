def funcaoa():
    print("Funcao A")