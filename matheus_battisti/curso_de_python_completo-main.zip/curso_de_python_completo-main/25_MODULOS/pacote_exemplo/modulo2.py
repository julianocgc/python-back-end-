def funcaob():
    print("Funcao B")